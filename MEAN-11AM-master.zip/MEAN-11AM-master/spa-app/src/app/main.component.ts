import { Component } from "@angular/core";

@Component({
    selector:"main-ashokit",
    templateUrl:"./main.component.html"
})
export default class mainComponent{

}