import { Component } from "@angular/core";

@Component({
    selector:"master",
    templateUrl:"./master.component.html"
})

export default class masterComponent{}