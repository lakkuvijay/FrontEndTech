import React, { createContext } from "react";
export const loginContext:any = createContext({});