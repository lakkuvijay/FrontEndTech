import React from "react";

function Heavy(){
    return(
        <React.Fragment>
            <h1>Heavy Component....!</h1>
        </React.Fragment>
    )
}

export default Heavy;