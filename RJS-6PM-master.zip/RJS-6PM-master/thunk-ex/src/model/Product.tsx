interface Product{
    "image":string;
}
export default Product;