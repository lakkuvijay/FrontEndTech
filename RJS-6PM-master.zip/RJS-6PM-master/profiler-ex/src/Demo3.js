import React from "react";

const Demo3 = ({key1})=>{
    console.log("Demo3");
    return(
        <React.Fragment>
            <h1>{key1}</h1>
        </React.Fragment>
    )
};

export default Demo3;