import React from "react";

const Demo2 = ({key1})=>{
    console.log("Demo2");
    return(
        <React.Fragment>
            <h1>{key1}</h1>
        </React.Fragment>
    )
};

export default Demo2;